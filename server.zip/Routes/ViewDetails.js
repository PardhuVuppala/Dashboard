const express = require('express');
const router = express.Router();
const pool = require('../dbconfig');

router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const result = await pool.query('SELECT * FROM admin WHERE username = $1', [username]);

        if (result.rows.length === 0) {
            return res.status(401).json({ message: 'Username or password is incorrect' });
        }
        
        const user = result.rows[0];

        if (password === user.password) {
            return res.status(200).json({ message: 'Login successful' });
        } else {
            return res.status(401).json({ message: 'Username or password is incorrect' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});


router.get('/highest-leave', async (req, res) => {
    try {
        const query = `
            SELECT employee_id, SUM(days_taken) AS total_days
            FROM leavedetails
            GROUP BY employee_id
            ORDER BY total_days DESC
            LIMIT 1;
        `;
        const result = await pool.query(query);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'No leave records found' });
        }

        const { employee_id, total_days } = result.rows[0];

        const details = await pool.query('SELECT * FROM employee WHERE id = $1', [employee_id]);
    
        if (details.rows.length > 0) {
            const employee = details.rows[0];
            const emp_name = employee.name;
            const emp_id = employee.id; 
            const mobile_number = employee.mobile_number;
            const email = employee.email;

            return res.status(200).json({
                employee_id,
                total_days,
                emp_name,
                emp_id,
                mobile_number,
                email
            });
        } else {
            return res.status(404).json({ message: 'Employee not found' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

router.get("/totalleaves", async (req, res) => {
    try {
        const leaveQuery = `
            SELECT employee_id, SUM(days_taken) AS total_days
            FROM leavedetails
            GROUP BY employee_id
            ORDER BY total_days 
        `;

        const leaveResult = await pool.query(leaveQuery);

        if (leaveResult.rows.length === 0) {
            return res.status(404).json({ message: 'No leave records found' });
        }
        const employeeIds = leaveResult.rows.map(row => row.employee_id);
        const employeeQuery = `
            SELECT * FROM employee
            WHERE id = ANY($1::int[])
        `;

        const employeeResult = await pool.query(employeeQuery, [employeeIds]);

        if (employeeResult.rows.length === 0) {
            return res.status(404).json({ message: 'No employee records found' });
        }
        const employeeMap = employeeResult.rows.reduce((map, emp) => {
            map[emp.id] = emp;
            return map;
        }, {});

        const combinedResults = leaveResult.rows.map(leave => ({
            ...employeeMap[leave.employee_id],
            total_days: leave.total_days
        }));

        res.status(200).json(combinedResults);

    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});





router.get('/least-leave', async (req, res) => {
    try {
        const query = `
            SELECT employee_id, SUM(days_taken) AS total_days
            FROM leavedetails
            GROUP BY employee_id
            ORDER BY total_days ASC
            LIMIT 1;
        `;
        const result = await pool.query(query);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'No leave records found' });
        }

        const { employee_id, total_days } = result.rows[0];

        const details = await pool.query('SELECT * FROM employee WHERE id = $1', [employee_id]);
    
        if (details.rows.length > 0) {
            const employee = details.rows[0];
            const emp_name = employee.name;
            const emp_id = employee.id; 
            const mobile_number = employee.mobile_number;
            const email = employee.email;

            return res.status(200).json({
                employee_id,
                total_days,
                emp_name,
                emp_id,
                mobile_number,
                email
            });
        } else {
            return res.status(404).json({ message: 'Employee not found' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});



router.get('/absent-today', async (req, res) => {
    try {
        const today = new Date().toISOString().split('T')[0];
        const query = `
            SELECT COUNT(DISTINCT employee_id) AS absent_count
            FROM leavedetails
            WHERE $1 BETWEEN start_date AND end_date;
        `;
        
        const result = await pool.query(query, [today]);
        const absentCount = result.rows[0].absent_count;
        res.status(200).json({ absent_count: absentCount });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});



router.get('/absent-summary', async (req, res) => {
    try {
        const today = new Date().toISOString().split('T')[0];

        const minDateQuery = `
            SELECT MIN(start_date) AS min_date
            FROM leavedetails
        `;
        const minDateResult = await pool.query(minDateQuery);
        const minDate = minDateResult.rows[0].min_date;
        
        if (!minDate) {
            return res.status(404).json({ message: 'No leave records found' });
        }

        const generateDates = (startDate, endDate) => {
            const dates = [];
            let currentDate = new Date(startDate);
            const end = new Date(endDate);

            while (currentDate <= end) {
                dates.push(currentDate.toISOString().split('T')[0]);
                currentDate.setDate(currentDate.getDate() + 1);
            }
            return dates;
        };

        const dateRange = generateDates(minDate, today);

        const absenteeCounts = {};
        for (const date of dateRange) {
            const countQuery = `
                SELECT COUNT(DISTINCT employee_id) AS absent_count
                FROM leavedetails
                WHERE $1 BETWEEN start_date AND end_date
            `;
            const countResult = await pool.query(countQuery, [date]);
            absenteeCounts[date] = countResult.rows[0].absent_count || 0;
        }

        res.status(200).json(absenteeCounts);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

router.get('/employee-deatils', (req, res) => {
    pool.query('SELECT * FROM employee', (err, results) => {
      if (err) {
        return res.status(500).json({ message: 'Error fetching data' });
      }
      res.json(results.rows);
    });
  });

module.exports = router;




