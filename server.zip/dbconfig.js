const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres', 
  host: 'localhost',     
  database: 'Employee Record', 
  password: '9948805602', 
  port: 5432,
});

module.exports = pool;