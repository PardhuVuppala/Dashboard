import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; 

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate() 
  const handleSubmit = async (event) => {
    event.preventDefault();
    
    const payload = {
      username,
      password,
      
    };

    try {
      const response = await axios.post('http://localhost:1200/Details/login', payload);

      if (response.status === 200) {

        setSuccess('Login successful');
        setError('');
        navigate("/dashboard")
        console.log('Login successful');
      }
    } catch (error) {
      setError('Login failed. Please try again.');
      setSuccess('');
      console.error('An error occurred:', error);
    }
  };

  return (
    <div className="container-fluid">
      <div className="row vh-100">
        {/* left side */}
        <div className="col-md-6 d-none d-md-block bg-light">
        </div>
        <div className="col-md-6 d-flex justify-content-center align-items-center">
          <div style={{ maxWidth: '400px', width: '100%' }}>
            <h2 className="text-center mb-4">Login</h2>
            <form onSubmit={handleSubmit}>
              {success && <div className="alert alert-success">{success}</div>}
              {error && <div className="alert alert-danger">{error}</div>}
              <div className="mb-3">
                <label htmlFor="email" className="form-label">username:</label>
                <input 
                  type="text" 
                  className="form-control" 
                  id="email" 
                  placeholder="Enter email" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required 
                />
              </div>
              <div className="mb-3">
                <label htmlFor="password" className="form-label">Password:</label>
                <input 
                  type="password" 
                  className="form-control" 
                  id="password" 
                  placeholder="Enter password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required 
                />
              </div>
              <div className="mb-3 form-check">
                <input 
                  type="checkbox" 
                  className="form-check-input" 
                  id="rememberMe"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                required/>
                <label className="form-check-label" htmlFor="rememberMe">Remember me</label>
              </div>
              <div className="d-grid">
                            <button
                type="submit"
                className="btn btn-primary btn-sm"
                style={{ backgroundColor: '#2C3E50', borderColor: '#2C3E50' }}
                >
                Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;
