import React, { useEffect, useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';
import Img from './image.png'
function Employee() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:1200/Details/employee-deatils')
      .then(response => {
        console.log('API Response:', response.data);
        setEmployees(response.data); 
        setLoading(false);
      })
      .catch(error => {
        setError(error.message);
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="text-center mt-5"><div className="spinner-border" role="status"></div></div>;
  if (error) return <div className="alert alert-danger" role="alert">Error: {error}</div>;

  return (
    <div className="d-flex">
    <div style={{ backgroundColor: '#D9D9D9', width: '250px', minHeight: '100vh', display: 'flex', flexDirection: 'column',  position:"sticky"}} >
    <div className="p-3">
      <div className="d-flex align-items-center">
          <img
            src={Img}
            alt="User Avatar"
            className="rounded-circle"
            style={{ width: "40px", height: "40px" }}
          />
          <span className="ms-2 ml-2">Profile Name</span>
        </div>
        <nav className="nav flex-column mt-4">
          <Link className="nav-link" style={{color:"black"}} to="/dashboard">DashBoard</Link>
          <Link className="nav-link"  style={{color:"black"}} to="/employee">Employee</Link>
        </nav>
      </div>
    
    </div>

    <div className="flex-grow-1">
         
      <nav style={{ backgroundColor: "#D9D9D9", minHeight: "7vh", padding: "15px" }}>
           </nav>
      <div className="container mt-4">
      <div className="container mt-4">
      <h2 className="text-center mb-4">Employee List</h2>
      <div className="row">
        {employees.length === 0 ? (
          <p className="text-center">No employees found.</p>
        ) : (
          employees.map(employee => (
            <div className="col-md-4 mb-4" key={employee.id}>
              <div className="card" style={{ backgroundColor: '#D9D9D9', boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)' }}>
                <div className="card-body">
                  <h5 className="card-title">{employee.name}</h5>
                  <h6 className="card-subtitle mb-2 text-muted">Employee ID: {employee.emp_id}</h6>
                  <p className="card-text">
                    <strong>Email:</strong> {employee.email}<br />
                    <strong>Mobile Number:</strong> {employee.mobile_number}<br />
                    <strong>Address:</strong> {employee.address}
                  </p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
       
      </div>
    </div>
  </div>
    
  );
}

export default Employee;
