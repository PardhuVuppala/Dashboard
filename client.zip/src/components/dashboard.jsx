import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Img from './image.png';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';

function Dashboard() {
  const [highestLeave, setHighestLeave] = useState(null);
  const [leastLeave, setLeastLeave] = useState(null);
  const [leaveData, setLeaveData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate()

  useEffect(() => {
    axios.get('http://localhost:1200/Details/highest-leave')
      .then(response => {
        setHighestLeave(response.data);
      })
      .catch(error => {
        setError(error.message);
      });
 


    axios.get('http://localhost:1200/Details/least-leave')
      .then(response => {
        setLeastLeave(response.data);
      })
      .catch(error => {
        setError(error.message);
      })


      axios.get('http://localhost:1200/Details/totalleaves')
      .then(response => {
        setLeaveData(response.data);
      })
      .catch(error => {
        setError(error.message);
      })


      
      .finally(() => {
        setLoading(false);
      });




  }, []);

  const Logout=()=>
  {
    navigate("/")
  }

  if (loading) return <div className="text-center mt-5"><div className="spinner-border" role="status"></div></div>;
  if (error) return <div className="alert alert-danger" role="alert">Error: {error}</div>;

  return (
    <div className="d-flex">
    <div style={{ backgroundColor: '#D9D9D9', width: '250px', minHeight: '100vh', display: 'flex', flexDirection: 'column',  position:"sticky"}} >
    <div className="p-3">
          <div className="d-flex align-items-center">
            <img
              src={Img}
              alt="User Avatar"
              className="rounded-circle"
              style={{ width: "40px", height: "40px" }}
            />
            <span className="ms-2 ml-2">Profile Name</span>
          </div>
          <nav className="nav flex-column mt-4">
            <Link className="nav-link" style={{color:"black"}} to="/dashboard">DashBoard</Link>
            <Link className="nav-link" style={{color:"black"}} to="/employee" >Employee</Link>
          </nav>
        </div>
        <div className="mt-auto p-3">
          <button className="btn btn w-100" onClick={Logout}>Logout</button>
        </div>
      </div>

      <div className="flex-grow-1">
      
      <nav style={{ backgroundColor: "#D9D9D9", minHeight: "7vh", padding: "15px" }}>
           </nav>
        <div className="container mt-4">
  
          <div className="row">
            {highestLeave && (
              <div className="col-md-6 mb-4">
                <div className="card" style={{ backgroundColor: '#D9D9D9', boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)' }}>
                  <div className="card-body">
                    <h5 className="card-title">Employee with Highest Leaves</h5>
                    <h6 className="card-subtitle mb-2 text-muted">Employee ID: {highestLeave.employee_id}</h6>
                    <p className="card-text">
                      <strong>Name:</strong> {highestLeave.emp_name}<br />
                      <strong>Email:</strong> {highestLeave.email}<br />
                      <strong>Mobile Number:</strong> {highestLeave.mobile_number}<br />
                      <strong>Total Leave Days:</strong> {highestLeave.total_days}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {leastLeave && (
              <div className="col-md-6 mb-4">
                <div className="card" style={{ backgroundColor: '#D9D9D9', boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)' }}>
                  <div className="card-body">
                    <h5 className="card-title">Employee with Least Leaves</h5>
                    <h6 className="card-subtitle mb-2 text-muted">Employee ID: {leastLeave.employee_id}</h6>
                    <p className="card-text">
                      <strong>Name:</strong> {leastLeave.emp_name}<br />
                      <strong>Email:</strong> {leastLeave.email}<br />
                      <strong>Mobile Number:</strong> {leastLeave.mobile_number}<br />
                      <strong>Total Leave Days:</strong> {leastLeave.total_days}
                    </p>
                  </div>
                </div>
              </div>
            )}

            <h2 className="mb-4">Employee Leave Records</h2>
            <div style={{ height: "55vh", overflowY: "auto" }}>
                <table className="table table-striped" style={{ minWidth: "100%" }}>
                <thead>
                    <tr>
                    <th>Name</th>
                    <th>Employee ID</th>
                    <th>Email</th>
                    <th>Mobile Number</th>
                    <th>Address</th>
                    <th>Total Leave Days</th>
                    </tr>
                </thead>
                <tbody>
                    {leaveData.map(employee => (
                    <tr key={employee.id}>
                        <td>{employee.name}</td>
                        <td>{employee.emp_id}</td>
                        <td>{employee.email}</td>
                        <td>{employee.mobile_number}</td>
                        <td>{employee.address}</td>
                        <td>{employee.total_days}</td>
                    </tr>
                    ))}
                </tbody>
                </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
